import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    clearMocks: true,
    environment: 'node',
    restoreMocks: true,
    setupFiles: ['./test/setup.ts'],
    unstubEnvs: true,
  },
});
